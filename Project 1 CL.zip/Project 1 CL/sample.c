#include <stdio.h>

int main()
{
    //sample comment1
    int i=0;
    char c='a';
    i=i+1;
    float x= x*i/2;
    printf("hello world %f %a",x,c);
}