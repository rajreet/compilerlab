Compile the "main.c" file and run with the file directory as argument. I have provide a sample C file to test on.

Run this on terminal:

gcc main.c
./a.exe sample.c